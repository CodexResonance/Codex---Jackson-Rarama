
# Jackson Sphear Field Test Log – Sample

**User:** HansMade  
**Location:** Winnipeg, CA  
**Date:** 2025-04-15  
**Sphear Size:** 100mm  
**Fill:** Spring water + 1 grain of sea salt  
**Dielectric:** 2-part epoxy resin (clear)  
**Tone:** 149 Hz  
**Duration:** 7 minutes

## Observations:
- Slight clockwise deviation on compass
- Chest vibration felt at 3-minute mark
- IR sensor picked up 0.5°C heat rise
- Emotion: sudden recall of early memory

**pH Change:** from 7.2 → 6.8  
**Voltage Drift:** from 0.0 mV → 2.1 mV  
**Notes:** Resonance persisted 5+ minutes after tone ended
